# CoCRF-TrackNet-for-Satellite-Video
A Tracking Framework for Satellite Videos.  

/trackprocess 
--run_tracker.py is the py-file that executes the tracking program
for example:
'''bash
python run_tracker.py CoCRF(tracker_name) cocrf(para) --dataset IPIU --debug 1
'''

/tracker
Configuration for different tracker 

/network
The path of trained models

The training code will come soon.



